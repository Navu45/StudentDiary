import setuptools
setuptools.setup()